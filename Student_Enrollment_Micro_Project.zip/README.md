# Student Enrollment Form - Micro Project

A Flask + MySQL implementation of the Student Enrollment Form assignment.

## Features

- Primary key: Roll No
- On page load, only Roll No is enabled.
- Existing Roll No:
  - Loads the student record.
  - Disables Roll No.
  - Enables Update and Reset.
- New Roll No:
  - Enables the remaining fields.
  - Enables Save and Reset.
- Required-field validation.
- Save and Update operations use MySQL.
- Reset returns the form to the initial state.

## 1. Create the database

Open MySQL Workbench and run `schema.sql`.

## 2. Configure MySQL password

Open `app.py` and change:

```python
"password": "YOUR_MYSQL_PASSWORD",
```

to your actual MySQL root password.

## 3. Install Python packages

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Then:

```bash
pip install -r requirements.txt
```

## 4. Run

```bash
python app.py
```

Open:

http://127.0.0.1:5000

## 5. Test

### New record
1. Enter a new Roll No.
2. Press Enter or move out of the Roll No field.
3. Enter all remaining fields.
4. Click Save.
5. The form resets.

### Existing record
1. Enter an existing Roll No.
2. Press Enter or move out of the Roll No field.
3. Existing data appears.
4. Roll No becomes disabled.
5. Change any other field.
6. Click Update.
7. The form resets.

## Project structure

student_enrollment_project/
├── app.py
├── schema.sql
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
